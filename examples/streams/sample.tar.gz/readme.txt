README for the archive example.
This tar.gz holds a few small text files.
